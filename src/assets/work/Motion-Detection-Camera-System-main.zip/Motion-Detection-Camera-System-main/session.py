from flask import Flask,render_template,request,redirect,session,Response
import mysql.connector
import os

app=Flask(__name__)
app.secret_key=os.urandom(24)

# Database Connection
conn = mysql.connector.connect(host="localhost", user="root",password="",database="MDCS")
cursor=conn.cursor()

# Routes
@app.route('/getSession')
def getSession():
    current_user=getSession.form.get('user')
    # cursor.execute("SELECT * FROM `users` WHERE `id` LIKE '{}'".format(user_id))
    # users=cursor.fetchall()
    return current_user
if __name__=="__main__":
    getSession()